let tasks = [];
let currentDate = new Date();
let timerInterval;
let remainingTime;
let isPaused = true;
let notes = [];
let totalStudyTime = 0;
let studySessionsHistory = [];
let goals = [];
let sessionStartTime;
let totalTasksCompleted = 0;
let totalTasksCreated = 0;
let productivityStreak = 0;
let lastProductiveDay = null;
let charts = {};
let completedTasks = [];
let chatHistory = [];
let modules = [];
let currentModule = null;
let currentAssessmentType = null;
let currentAssessmentIndex = undefined;

document.addEventListener('DOMContentLoaded', function() {
    const authPage = document.getElementById('authPage');
    const appContent = document.getElementById('appContent');
    const authTabs = document.querySelectorAll('.auth-tab');
    const authForms = document.querySelectorAll('.auth-form');
    const loginForm = document.querySelector('#loginForm form');
    const registerForm = document.querySelector('#registerForm form');
    const authError = document.querySelector('#authError');

    // Show auth page and hide app content by default
    authPage.style.display = 'flex';
    appContent.style.display = 'none';

    // Check if user is already logged in
    const token = localStorage.getItem('token');
    if (token) {
        showApp();
    }

    // Tab switching
    authTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            authTabs.forEach(t => t.classList.remove('active'));
            authForms.forEach(f => f.classList.remove('active'));
            tab.classList.add('active');
            document.querySelector(`#${tab.dataset.tab}Form`).classList.add('active');
            authError.textContent = '';
        });
    });

    // Form submission
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        await handleAuth('login');
    });

    registerForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        await handleAuth('register');
    });

    // Initialize app components
    initializeApp();

    // Ensure this is only added once
    document.getElementById('sendButton').addEventListener('click', function() {
        const message = document.getElementById('userInput').value;
        sendMessageToAI(message);
    });
});

async function handleAuth(type) {
    const username = document.querySelector(`#${type}Username`).value;
    const password = document.querySelector(`#${type}Password`).value;

    try {
        const response = await fetch(`http://localhost:3001/${type}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ username, password }),
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || 'An error occurred');
        }

        if (type === 'login') {
            localStorage.setItem('token', data.token);
            showApp();
        } else {
            // Switch to login tab after successful registration
            document.querySelector('.auth-tab[data-tab="login"]').click();
            document.querySelector('#authError').textContent = 'Registration successful! Please log in.';
            document.querySelector('#authError').style.color = 'var(--secondary-color)';
        }
    } catch (error) {
        document.querySelector('#authError').textContent = error.message;
        document.querySelector('#authError').style.color = 'var(--error-color)';
    }
}

function setupAutoLogout() {
    window.addEventListener('beforeunload', function (e) {
        localStorage.removeItem('token');
    });
}

function showApp() {
    document.getElementById('authPage').style.display = 'none';
    document.getElementById('appContent').style.display = 'flex';
    initializeApp();
}

function initializeApp() {
    const token = localStorage.getItem('token');
    if (!token) {
        showAuthPage();
        return;
    }

    showPage('calendar');
    renderCalendar();
    startTimeUpdate();
    loadFromLocalStorage();
    setupAutoLogout();

    document.querySelectorAll('.menu-item').forEach(item => {
        item.addEventListener('click', (e) => {
            const pageId = e.target.getAttribute('page');
            showPage(pageId);
        });
    });

    const saveAssessmentBtn = document.getElementById('saveAssessmentBtn');
    if (saveAssessmentBtn) {
        saveAssessmentBtn.addEventListener('click', saveAssessment);
    }

    const closeAssessmentModalBtn = document.getElementById('closeAssessmentModalBtn');
    if (closeAssessmentModalBtn) {
        closeAssessmentModalBtn.addEventListener('click', () => closeModal('assessmentModal'));
    }

    const addButton = document.querySelector('.add-button');
    if (addButton) {
        addButton.addEventListener('click', () => showModal('addTaskModal'));
    }

    const closeModalButton = document.querySelector('.modal-content button:last-child');
    if (closeModalButton) {
        closeModalButton.addEventListener('click', () => closeModal('addTaskModal'));
    }

    const progressTrackingMenuItem = document.querySelector('.menu-item[page="progressTracking"]');
    if (progressTrackingMenuItem) {
        progressTrackingMenuItem.addEventListener('click', function() {
            showPage('progressTracking');
            updateProgressTracking();
        });
    }

    const sendButton = document.getElementById('sendButton');
    if (sendButton) {
        sendButton.addEventListener('click', handleSendMessage);
    }

    const userInput = document.getElementById('userInput');
    if (userInput) {
        userInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSendMessage();
            }
        });
    }

    const logoutButton = document.getElementById('logoutButton');
    if (logoutButton) {
        logoutButton.addEventListener('click', logout);
    }

    document.getElementById('startTimer')?.addEventListener('click', startTimer);
    document.getElementById('pauseTimer')?.addEventListener('click', pauseTimer);
    document.getElementById('resetTimer')?.addEventListener('click', resetTimer);
    document.getElementById('addGoalBtn')?.addEventListener('click', addGoal);

    const calendarHeader = document.getElementById('calendarHeader');
    if (calendarHeader) {
        const buttons = calendarHeader.querySelectorAll('button');
        const prevButton = buttons[0];
        const todayButton = buttons[1];
        const nextButton = buttons[2];

        prevButton.addEventListener('click', () => {
            currentDate.setMonth(currentDate.getMonth() - 1);
            renderCalendar();
        });

        todayButton.addEventListener('click', goToToday);

        nextButton.addEventListener('click', () => {
            currentDate.setMonth(currentDate.getMonth() + 1);
            renderCalendar();
        });
    }

    document.addEventListener('submit', function(event) {
        if (event.target.id === 'addNoteForm') {
            addNote(event);
        }
    });

    document.getElementById('taskName')?.addEventListener('input', validateTaskForm);
    document.getElementById('taskDate')?.addEventListener('input', validateTaskForm);
    document.getElementById('taskTime')?.addEventListener('input', validateTaskForm);
    document.getElementById('taskPriority')?.addEventListener('change', validateTaskForm);
    document.getElementById('taskColor')?.addEventListener('input', validateTaskForm);
    document.getElementById('taskSubject')?.addEventListener('input', validateTaskForm);

    const addTaskButton = document.getElementById('addTaskButton');
    if (addTaskButton) {
        addTaskButton.addEventListener('click', addTask);
    }

    const clearChatButton = document.getElementById('clearChatButton');
    if (clearChatButton) {
        clearChatButton.addEventListener('click', clearChat);
    }

    const addModuleBtn = document.getElementById('addModuleBtn');
    if (addModuleBtn) {
        addModuleBtn.addEventListener('click', addModule);
    }

    loadChatHistory();

    // Add Task Modal functionality
    const addTaskBtn = document.querySelector('.add-button');
    const addTaskModal = document.getElementById('addTaskModal');
    const taskInputs = addTaskModal.querySelectorAll('input, select, textarea');

    addTaskBtn.addEventListener('click', () => {
        openModal('addTaskModal');
        // Reset form fields
        taskInputs.forEach(input => {
            if (input.type === 'color') {
                input.value = '#4CAF50';
            } else {
                input.value = '';
            }
        });
        validateTaskForm(); // Check initial form state
    });

    // Add input validation
    taskInputs.forEach(input => {
        input.addEventListener('input', validateTaskForm);
    });

    addTaskButton.addEventListener('click', () => {
        const taskData = {
            name: document.getElementById('taskName').value,
            date: document.getElementById('taskDate').value,
            time: document.getElementById('taskTime').value,
            priority: document.getElementById('taskPriority').value,
            color: document.getElementById('taskColor').value,
            subject: document.getElementById('taskSubject').value,
            notes: document.getElementById('taskNotes').value
        };

        addTask(taskData);
    });

    // Add clear history button listener
    const clearHistoryBtn = document.getElementById('clearHistoryBtn');
    if (clearHistoryBtn) {
        clearHistoryBtn.addEventListener('click', () => {
            if (confirm('Are you sure you want to clear all progress history? This cannot be undone.')) {
                clearProgressHistory();
            }
        });
    }
}

function logout() {
    localStorage.removeItem('token');
    showAuthPage();
}

function showAuthPage() {
    document.getElementById('authPage').style.display = 'flex';
    document.getElementById('appContent').style.display = 'none';
}

function showPage(pageId) {
    document.querySelectorAll('.page').forEach(page => {
        page.style.display = 'none';
    });
    
    const selectedPage = document.getElementById(pageId);
    if (selectedPage) {
        selectedPage.style.display = 'block';
        if (pageId === 'calculateGrade') {
            renderModules();
        }
    }

    document.querySelectorAll('.menu-item').forEach(item => item.classList.remove('active'));
    const activeMenuItem = document.querySelector(`.menu-item[page="${pageId}"]`);
    if (activeMenuItem) {
        activeMenuItem.classList.add('active');
    }

    if (pageId === 'calendar') {
        renderCalendar();
        startTimeUpdate();
    } else {
        stopTimeUpdate();
    }
    if (pageId === 'schedule') {
        renderSchedule();
    } else if (pageId === 'notes') {
        renderNotes();
    } else if (pageId === 'progressTracking') {
        showProgressTracking();
    }
    if (pageId === 'askAI') {
        loadChatHistory();
        renderChatHistory();
    }
}

function renderCalendar() {
    const calendarGrid = document.getElementById('calendarGrid');
    const currentMonth = document.getElementById('currentMonth');
    calendarGrid.innerHTML = '';

    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    currentMonth.textContent = `${currentDate.toLocaleString('default', { month: 'long' })} ${year}`;

    updateTimeDisplay();

    // Add day names
    const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    dayNames.forEach(dayName => {
        const dayNameElement = document.createElement('div');
        dayNameElement.className = 'calendar-day day-name';
        dayNameElement.textContent = dayName;
        calendarGrid.appendChild(dayNameElement);
    });

    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);

    for (let i = 0; i < firstDay.getDay(); i++) {
        const dayElement = createDayElement(new Date(year, month, -firstDay.getDay() + i + 1));
        dayElement.classList.add('different-month');
        calendarGrid.appendChild(dayElement);
    }

    for (let i = 1; i <= lastDay.getDate(); i++) {
        const dayElement = createDayElement(new Date(year, month, i));
        calendarGrid.appendChild(dayElement);
    }

    for (let i = 1; i <= (42 - lastDay.getDate() - firstDay.getDay()); i++) {
        const dayElement = createDayElement(new Date(year, month + 1, i));
        dayElement.classList.add('different-month');
        calendarGrid.appendChild(dayElement);
    }
}

function createDayElement(date) {
    const dayElement = document.createElement('div');
    dayElement.className = 'calendar-day';
    dayElement.textContent = date.getDate();

    if (date.toDateString() === new Date().toDateString()) {
        dayElement.classList.add('today');
    }

    const tasksForDay = tasks.filter(task => {
        const taskDate = new Date(task.date);
        return taskDate.toDateString() === date.toDateString();
    });

    tasksForDay.forEach(task => {
        const taskElement = document.createElement('div');
        taskElement.className = 'event';
        taskElement.textContent = task.name;
        taskElement.style.backgroundColor = task.color;
        dayElement.appendChild(taskElement);
    });

    return dayElement;
}

function updateTimeDisplay() {
    const currentTime = document.getElementById('currentTime');
    const now = new Date();
    currentTime.textContent = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

let timeUpdateInterval;

function startTimeUpdate() {
    updateTimeDisplay();
    timeUpdateInterval = setInterval(updateTimeDisplay, 1000);
}

function stopTimeUpdate() {
    clearInterval(timeUpdateInterval);
}

function renderSchedule() {
    const todayTasks = document.getElementById('todayTasks');
    const tomorrowTasks = document.getElementById('tomorrowTasks');
    const upcomingTasks = document.getElementById('upcomingTasks');
    
    // Clear existing content
    todayTasks.innerHTML = '<h3>Today</h3>';
    tomorrowTasks.innerHTML = '<h3>Tomorrow</h3>';
    upcomingTasks.innerHTML = '<h3>Upcoming</h3>';
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    tasks.forEach(task => {
        const taskDate = new Date(task.date);
        taskDate.setHours(0, 0, 0, 0);
        
        const taskElement = createTaskElement(task);
        
        if (taskDate.getTime() === today.getTime()) {
            todayTasks.appendChild(taskElement);
        } else if (taskDate.getTime() === tomorrow.getTime()) {
            tomorrowTasks.appendChild(taskElement);
        } else if (taskDate > today) {
            upcomingTasks.appendChild(taskElement);
        }
    });
}

function createTaskElement(task) {
    const taskElement = document.createElement('div');
    taskElement.className = 'task';
    taskElement.style.backgroundColor = task.color;
    taskElement.innerHTML = `
        <h4>${task.name}</h4>
        <p>${task.date} ${task.time}</p>
        <p>Priority: ${task.priority}</p>
        <button onclick="editTask(${task.id})">Edit</button>
        <button onclick="deleteTask(${task.id})">Delete</button>
        <input type="checkbox" ${task.completed ? 'checked' : ''} onchange="toggleTaskCompletion(${task.id})">
    `;
    return taskElement;
}

function validateTaskForm() {
    const taskName = document.getElementById('taskName').value.trim();
    const taskDate = document.getElementById('taskDate').value;
    const taskTime = document.getElementById('taskTime').value;
    const taskPriority = document.getElementById('taskPriority').value;
    const taskColor = document.getElementById('taskColor').value;
    const taskSubject = document.getElementById('taskSubject').value.trim();

    const isValid = taskName && taskDate && taskTime && taskPriority && taskColor && taskSubject;
    const addTaskButton = document.getElementById('addTaskButton');
    
    if (addTaskButton) {
        addTaskButton.disabled = !isValid;
    }
}

function addTask(taskData) {
    // Generate a unique ID for the task
    taskData.id = Date.now().toString();
    tasks.push(taskData);
    updateTaskStatistics(true); // New task created
    saveToLocalStorage();
    renderCalendar();
    showNotification('Task added successfully');
    closeModal('addTaskModal');
}

function editTask(taskId) {
    const task = tasks.find(task => task.id === taskId);
    if (task) {
        document.getElementById('taskName').value = task.name;
        document.getElementById('taskDate').value = task.date;
        document.getElementById('taskTime').value = task.time;
        document.getElementById('taskPriority').value = task.priority;
        document.getElementById('taskColor').value = task.color;
        document.getElementById('taskNotes').value = task.notes;
        document.getElementById('taskSubject').value = task.subject;

        // Do NOT delete the task here
        showModal('addTaskModal');
        validateTaskForm();
    }
}

function deleteTask(taskId) {
    const taskIndex = tasks.findIndex(task => task.id === taskId);
    if (taskIndex !== -1) {
    tasks.splice(taskIndex, 1);
    saveToLocalStorage();
    renderSchedule();
    renderCalendar();
    updateProgressTracking();
    showNotification('Task deleted successfully');
    } else {
    showNotification('Task not found.');
    }
}
function toggleTaskCompletion(taskId) {
    const taskIndex = tasks.findIndex(task => task.id === taskId);
    if (taskIndex !== -1) {
        const task = tasks[taskIndex];
        task.completed = !task.completed;
        
        if (task.completed) {
            completedTasks.push({...task});
            tasks.splice(taskIndex, 1);
            totalTasksCompleted++;
            
            // Update productivity streak
            const today = new Date().toDateString();
            if (lastProductiveDay !== today) {
                productivityStreak++;
                lastProductiveDay = today;
            }
        }
        
        saveToLocalStorage();
        renderSchedule();
        renderCalendar();
        updateProgressTracking();
        showNotification(task.completed ? 'Task completed!' : 'Task uncompleted');
    }
}

function startTimer() {
    if (isPaused) {
        isPaused = false;
        const focusTime = document.getElementById('focusTime').value;
        remainingTime = focusTime * 60;
        timerInterval = setInterval(updateTimer, 1000);
        updateTimerDisplay();
        
        sessionStartTime = Date.now();
    }
}

function pauseTimer() {
    if (!isPaused) {
        isPaused = true;
        clearInterval(timerInterval);
    }
}

function resetTimer() {
    clearInterval(timerInterval);
    isPaused = true;
    const focusTime = document.getElementById('focusTime').value;
    remainingTime = focusTime * 60;
    updateTimerDisplay();
}

function updateTimer() {
    if (remainingTime > 0) {
        remainingTime--;
        updateTimerDisplay();
    } else {
        clearInterval(timerInterval);
        alert("Time's up!");
        
        const sessionDuration = (Date.now() - sessionStartTime) / 60000;
        totalStudyTime += sessionDuration;
        studySessionsHistory.push({
            date: new Date().toLocaleDateString(),
            duration: sessionDuration
        });
        updateProgressTracking();
    }
}

function updateTimerDisplay() {
    const minutes = Math.floor(remainingTime / 60);
    const seconds = remainingTime % 60;
    document.getElementById('timerDisplay').textContent = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
}

function showModal(modalId) {
    document.getElementById(modalId).style.display = 'block';
}

function scheduleNotification(task) {
    const taskTime = new Date(`${task.date}T${task.time}`);
    const notificationTime = taskTime.getTime() - 5 * 60 * 1000;
    const currentTime = new Date().getTime();

    if (notificationTime > currentTime) {
        setTimeout(() => {
            showNotification(`Upcoming Task: ${task.name}`);
        }, notificationTime - currentTime);
    }
}

function showNotification(message) {
    const notificationArea = document.getElementById('notificationArea');
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.textContent = message;
    notificationArea.appendChild(notification);

    setTimeout(() => {
        notification.remove();
    }, 5000);
}

function addNote(event) {
    event.preventDefault();

    const form = event.target;
    const title = form.querySelector('#noteTitle').value.trim();
    const content = form.querySelector('#noteContent').value.trim();

    if (title && content) {
        const note = {
            id: Date.now(),
            title: title,
            content: content
        };
        notes.push(note);
        renderNotes();
        saveNotesToLocalStorage();
        form.reset();
    }
}

function renderNotes() {
    const notesList = document.getElementById('notesList');
    if (notesList) {
        notesList.innerHTML = '';
        notes.forEach(note => {
            const noteElement = document.createElement('div');
            noteElement.className = 'note';
            noteElement.innerHTML = `
                <h3>${note.title}</h3>
                <p>${note.content}</p>
                <button onclick="editNote(${note.id})">Edit</button>
                <button onclick="deleteNote(${note.id})">Delete</button>
            `;
            notesList.appendChild(noteElement);
        });
    }
}

function editNote(noteId) {
    const note = notes.find(n => n.id === noteId);
    if (note) {
        document.getElementById('noteTitle').value = note.title;
        document.getElementById('noteContent').value = note.content;
        deleteNote(noteId);
        saveNotesToLocalStorage();
    }
}

function deleteNote(noteId) {
    notes = notes.filter(note => note.id !== noteId);
    renderNotes();
    saveNotesToLocalStorage();
}

function saveNotesToLocalStorage() {
    localStorage.setItem('notes', JSON.stringify(notes));
}

function loadNotesFromLocalStorage() {
    const savedNotes = localStorage.getItem('notes');
    if (savedNotes) {
        notes = JSON.parse(savedNotes);
    }
}

function showProgressTracking() {
    updateTaskCompletionChart();
    updateStudyTimeChart();
    updateProductivityStreak();
    updateSubjectPerformance();
    updateGoalsProgress();
}

function updateTaskCompletionChart() {
    const totalCompletedTasks = completedTasks.length;
    const totalActiveTasks = tasks.length;
    const completionRate = (totalCompletedTasks + totalActiveTasks) > 0 
        ? (totalCompletedTasks / (totalCompletedTasks + totalActiveTasks)) * 100 
        : 0;

    const ctx = document.getElementById('taskCompletionChart').getContext('2d');
    
    if (charts.taskCompletion) {
        charts.taskCompletion.destroy();
    }
    
    charts.taskCompletion = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Completed', 'Active'],
            datasets: [{
                data: [totalCompletedTasks, totalActiveTasks],
                backgroundColor: ['#4CAF50', '#FFA500']
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: 'Task Completion'
                },
                legend: {
                    position: 'bottom',
                    labels: {
                        color: '#ffffff'
                    }
                }
            }
        }
    });

    document.getElementById('taskCompletionRate').textContent = `Task Completion Rate: ${completionRate.toFixed(2)}%`;
}

function updateStudyTimeChart() {
    const ctx = document.getElementById('studyTimeChart').getContext('2d');
    
    if (charts.studyTime) {
        charts.studyTime.destroy();
    }
    
    charts.studyTime = new Chart(ctx, {
        type: 'line',
        data: {
            labels: studySessionsHistory.map(session => session.date),
            datasets: [{
                label: 'Study Time (minutes)',
                data: studySessionsHistory.map(session => session.duration),
                borderColor: '#4CAF50',
                fill: false
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: 'Study Time History'
                },
                tooltip: {
                    callbacks: {
                        label: (context) => `${context.dataset.label}: ${context.parsed.y.toFixed(2)} minutes`
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Study Time (minutes)'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Date'
                    }
                }
            }
        }
    });

    document.getElementById('totalStudyTime').textContent = `Total Study Time: ${totalStudyTime.toFixed(2)} minutes`;
}

function updateProductivityStreak() {
    const today = new Date().toDateString();
    if (lastProductiveDay !== today) {
        if (lastProductiveDay === new Date(Date.now() - 86400000).toDateString()) {
            productivityStreak++;
        } else {
            productivityStreak = 1;
        }
        lastProductiveDay = today;
    }
    document.getElementById('productivityStreak').textContent = `Current Streak: ${productivityStreak} days`;
}

function updateSubjectPerformance() {
    const subjects = {};
    completedTasks.forEach(task => {
        subjects[task.subject] = (subjects[task.subject] || 0) + 1;
    });

    const ctx = document.getElementById('subjectPerformanceChart').getContext('2d');
    
    if (charts.subjectPerformance) {
        charts.subjectPerformance.destroy();
    }
    
    charts.subjectPerformance = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: Object.keys(subjects),
            datasets: [{
                label: 'Completed Tasks per Subject',
                data: Object.values(subjects),
                backgroundColor: '#4CAF50'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: 'Subject Performance'
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Completed Tasks'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Subjects'
                    }
                }
            }
        }
    });
}

function updateGoalsProgress() {
    const goalsElement = document.getElementById('goalsProgress');
    goalsElement.innerHTML = '';

    goals.forEach(goal => {
        const goalElement = document.createElement('div');
        goalElement.className = 'goal';
        goalElement.innerHTML = `
            <h4>${goal.name}</h4>
            <div class="progress-wrapper">
                <progress value="${goal.progress}" max="100"></progress>
                <span>${goal.progress}%</span>
            </div>
            <div class="goal-actions">
                <button onclick="editGoal(${goal.id})">Edit</button>
                <button onclick="deleteGoal(${goal.id})">Delete</button>
            </div>
        `;
        goalsElement.appendChild(goalElement);
    });
}

function addGoal() {
    const goalName = prompt('Enter goal name:');
    if (goalName) {
        const newGoal = { id: Date.now(), name: goalName, progress: 0 };
        goals.push(newGoal);
        updateGoalsProgress();
        saveToLocalStorage();
    }
}

function editGoal(goalId) {
    const goal = goals.find(g => g.id === goalId);
    if (goal) {
        const newName = prompt('Enter new goal name:', goal.name);
        const newProgress = prompt('Enter new progress (0-100):', goal.progress);
        if (newName && !isNaN(newProgress)) {
            goal.name = newName;
            goal.progress = Math.min(100, Math.max(0, parseInt(newProgress)));
            updateGoalsProgress();
            saveToLocalStorage();
        }
    }
}

function deleteGoal(goalId) {
    goals = goals.filter(g => g.id !== goalId);
    updateGoalsProgress();
    saveToLocalStorage();
}

function addModule() {
    const moduleName = prompt("Enter module name:");
    if (moduleName) {
        const module = {
            id: Date.now(),
            name: moduleName,
            tests: [],
            quizzes: [],
            assignments: [],
            exam: null
        };
        modules.push(module);
        renderModules();
        saveToLocalStorage();
    }
}

function deleteModule(moduleId) {
    if (confirm('Are you sure you want to delete this module?')) {
        modules = modules.filter(m => m.id !== moduleId);
        renderModules();
        saveToLocalStorage();
    }
}

function renderModules() {
    const modulesContainer = document.getElementById('modules');
    if (!modulesContainer) {
        console.error("Modules container not found");
        return;
    }
    modulesContainer.innerHTML = '';
    modules.forEach(module => {
        const moduleElement = createModuleElement(module);
        modulesContainer.appendChild(moduleElement);
    });
}

function createModuleElement(module) {
    const moduleElement = document.createElement('div');
    moduleElement.className = 'module';
    moduleElement.innerHTML = `
        <h3>${module.name}</h3>
        <div class="assessment-section">
            <h4>Tests</h4>
            <div id="tests-${module.id}"></div>
            <button onclick="showAddAssessmentModal(${module.id}, 'test')" class="secondary-button">Add Test</button>
        </div>
        <div class="assessment-section">
            <h4>Quizzes</h4>
            <div id="quizzes-${module.id}"></div>
            <button onclick="showAddAssessmentModal(${module.id}, 'quiz')" class="secondary-button">Add Quiz</button>
        </div>
        <div class="assessment-section">
            <h4>Assignments/Projects</h4>
            <div id="assignments-${module.id}"></div>
            <button onclick="showAddAssessmentModal(${module.id}, 'assignment')" class="secondary-button">Add Assignment/Project</button>
        </div>
        <div class="assessment-section">
            <h4>Exam</h4>
            <div id="exam-${module.id}"></div>
            <button onclick="showAddAssessmentModal(${module.id}, 'exam')" class="secondary-button">Set Exam</button>
        </div>
        <div class="grade-result">
            <h4>Final Grade: <span id="final-grade-${module.id}">Not calculated</span></h4>
            <button onclick="calculateGrade(${module.id})" class="primary-button">Calculate Grade</button>
        </div>
        <button onclick="deleteModule(${module.id})" class="delete-button">Delete Module</button>
    `;

    setTimeout(() => {
        renderAssessments(module, 'test');
        renderAssessments(module, 'quiz');
        renderAssessments(module, 'assignment');
        renderExam(module);
    }, 0);

    return moduleElement;
}

function showAddAssessmentModal(moduleId, type) {
    currentModule = modules.find(m => m.id === moduleId);
    currentAssessmentType = type;

    if (!currentModule) {
        console.error('Module not found');
        alert('Error: Module not found');
        return;
    }

    document.getElementById('assessmentModalTitle').textContent = `Add ${type.charAt(0).toUpperCase() + type.slice(1)}`;
    document.getElementById('assessmentName').value = '';
    document.getElementById('assessmentScore').value = '';
    document.getElementById('assessmentTotalScore').value = '';
    document.getElementById('assessmentWeight').value = '';
    showModal('assessmentModal');
}

function saveAssessment() {
    const name = document.getElementById('assessmentName').value;
    const score = parseFloat(document.getElementById('assessmentScore').value);
    const totalScore = parseFloat(document.getElementById('assessmentTotalScore').value);
    const weight = parseFloat(document.getElementById('assessmentWeight').value);

    if (name && !isNaN(score) && !isNaN(totalScore) && !isNaN(weight) && score >= 0 && totalScore > 0 && weight > 0 && weight <= 100) {
        const assessment = { name, score, totalScore, weight };
        
        if (!currentModule) {
            console.error('No module selected');
            alert('Error: No module selected');
            return;
        }

        if (currentAssessmentType === 'exam') {
            currentModule.exam = assessment;
        } else {
            const containerType = currentAssessmentType === 'quiz' ? 'quizzes' : `${currentAssessmentType}s`;
            
            if (!currentModule[containerType]) {
                currentModule[containerType] = [];
            }
            
            if (currentAssessmentIndex !== null && currentAssessmentIndex !== undefined) {
                // Editing existing assessment
                currentModule[containerType][currentAssessmentIndex] = assessment;
            } else {
                // Adding new assessment
                currentModule[containerType].push(assessment);
            }
        }

        renderModules();
        saveToLocalStorage();
        closeModal('assessmentModal');

        // Clear the form fields and reset current assessment editing state
        document.getElementById('assessmentName').value = '';
        document.getElementById('assessmentScore').value = '';
        document.getElementById('assessmentTotalScore').value = '';
        document.getElementById('assessmentWeight').value = '';
        currentAssessmentIndex = undefined;
    } else {
        alert('Please enter valid values for all fields.');
    }
}

function renderAssessments(module, type) {
    const containerType = type === 'quiz' ? 'quizzes' : `${type}s`;
    const container = document.getElementById(`${containerType}-${module.id}`);
    if (!container) {
        console.error(`Container for ${containerType} not found for module ${module.id}`);
        return;
    }
    container.innerHTML = '';
    
    const assessments = module[containerType] || [];
    
    assessments.forEach((assessment, index) => {
        const assessmentElement = document.createElement('div');
        assessmentElement.className = 'assessment-item';
        assessmentElement.innerHTML = `
            <span>${assessment.name}: ${assessment.score}/${assessment.totalScore} (Weight: ${assessment.weight}%)</span>
            <div>
                <button onclick="editAssessment(${module.id}, '${type}', ${index})" class="edit-button">Edit</button>
                <button onclick="deleteAssessment(${module.id}, '${type}', ${index})" class="delete-button">Delete</button>
            </div>
        `;
        container.appendChild(assessmentElement);
    });
}

function renderExam(module) {
    const container = document.getElementById(`exam-${module.id}`);
    if (!container) {
        console.error(`Exam container not found for module ${module.id}`);
        return;
    }
    container.innerHTML = '';
    if (module.exam) {
        const examElement = document.createElement('div');
        examElement.className = 'assessment-item';
        examElement.innerHTML = `
            <span>${module.exam.name}: ${module.exam.score}/${module.exam.totalScore} (Weight: ${module.exam.weight}%)</span>
            <div>
                <button onclick="editAssessment(${module.id}, 'exam')" class="edit-button">Edit</button>
                <button onclick="deleteAssessment(${module.id}, 'exam')" class="delete-button">Delete</button>
            </div>
        `;
        container.appendChild(examElement);
    } else {
        container.innerHTML = '<p>No exam set</p>';
    }
}

function editAssessment(moduleId, type, index) {
    const module = modules.find(m => m.id === moduleId);
    if (!module) {
        console.error(`Module not found: ${moduleId}`);
        alert('Error: Module not found');
        return;
    }

    let assessment;
    if (type === 'exam') {
        assessment = module.exam;
    } else {
        const containerType = type === 'quiz' ? 'quizzes' : `${type}s`;
        const assessments = module[containerType];
        
        if (!assessments || !Array.isArray(assessments)) {
            console.error(`Assessments array not found for type: ${containerType}`);
            alert(`Error: No ${containerType} found for this module`);
            return;
        }

        assessment = assessments[index];
    }

    if (!assessment) {
        console.error(`Assessment not found`);
        alert('Error: Assessment not found');
        return;
    }

    document.getElementById('assessmentName').value = assessment.name;
    document.getElementById('assessmentScore').value = assessment.score;
    document.getElementById('assessmentTotalScore').value = assessment.totalScore;
    document.getElementById('assessmentWeight').value = assessment.weight;

    // Store the current module, assessment type, and index for use in saveAssessment
    currentModule = module;
    currentAssessmentType = type;
    currentAssessmentIndex = type === 'exam' ? null : index;

    showModal('assessmentModal');
}

function deleteAssessment(moduleId, type, index) {
    const module = modules.find(m => m.id === moduleId);
    if (!module) return;

    if (type === 'exam') {
        module.exam = null;
    } else {
        const containerType = type === 'quiz' ? 'quizzes' : `${type}s`;
        if (module[containerType] && Array.isArray(module[containerType])) {
            module[containerType].splice(index, 1);
        } else {
            console.error(`Invalid assessment type or array: ${containerType}`);
            return;
        }
    }
    renderModules();
    saveToLocalStorage();
}

function calculateGrade(moduleId) {
    const module = modules.find(m => m.id === moduleId);
    if (!module) return;

    let totalWeight = 0;
    let weightedSum = 0;

    function processAssessments(assessments) {
        assessments.forEach(assessment => {
            const percentage = (assessment.score / assessment.totalScore) * 100;
            totalWeight += assessment.weight;
            weightedSum += (percentage * assessment.weight / 100);
        });
    }

    processAssessments(module.tests);
    processAssessments(module.quizzes);
    processAssessments(module.assignments);
    if (module.exam) {
        const examPercentage = (module.exam.score / module.exam.totalScore) * 100;
        totalWeight += module.exam.weight;
        weightedSum += (examPercentage * module.exam.weight / 100);
    }

    if (Math.abs(totalWeight - 100) > 0.01) {
        alert(`Warning: Total weight is ${totalWeight.toFixed(2)}%, not 100%`);
    }

    const finalGrade = weightedSum;
    document.getElementById(`final-grade-${moduleId}`).textContent = finalGrade.toFixed(2) + '%';
}

async function handleSendMessage() {
    const userInput = document.getElementById('userInput');
    const message = userInput.value.trim();
    
    if (message) {
        addMessageToChat(message, 'user');
        userInput.value = '';
    
        try {
            const thinkingMessage = addMessageToChat('Thinking...', 'ai');
            const aiResponse = await sendMessageToAI(message);
            thinkingMessage.remove();
            addMessageToChat(aiResponse, 'ai');
            saveChatHistory(); // Save chat history after each message
        } catch (error) {
            addMessageToChat("Sorry, I couldn't process your request at this time.", 'ai');
        }
    }
}

function addMessageToChat(message, sender) {
    const chatMessages = document.getElementById('chatMessages');
    const messageElement = document.createElement('div');
    messageElement.classList.add('message', `${sender}-message`);
    messageElement.textContent = message;
    chatMessages.appendChild(messageElement);
    chatMessages.scrollTop = chatMessages.scrollHeight;
    chatHistory.push({ sender, message });
}

return messageElement;

function clearChat() {
    const chatMessages = document.getElementById('chatMessages');
    chatMessages.innerHTML = '';
    localStorage.removeItem('chatHistory');
}

function saveChatHistory() {
    const chatMessages = document.getElementById('chatMessages');
    localStorage.setItem('chatHistory', JSON.stringify(chatHistory));
}

function loadChatHistory() {
    const chatMessages = document.getElementById('chatMessages');
    const savedHistory = localStorage.getItem('chatHistory');
    if (savedHistory) {
        chatMessages.innerHTML = savedHistory;
    }
}

function renderChatHistory() {
    const chatMessages = document.getElementById('chatMessages');
    chatMessages.innerHTML = '';
    chatHistory.forEach(msg => addMessageToChat(msg.message, msg.sender));
}

async function sendMessageToAI(message) {
    try {
        const response = await fetch('http://localhost:3001/ask', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            },
            body: JSON.stringify({ message })
        });

        if (!response.ok) {
            throw new Error('Network response was not ok');
        }

        const data = await response.json();
        return data.response;
    } catch (error) {
        console.error('Error sending message to AI:', error);
        throw error;
    }
}

function saveToLocalStorage() {
    localStorage.setItem('tasks', JSON.stringify(tasks));
    localStorage.setItem('completedTasks', JSON.stringify(completedTasks));
    localStorage.setItem('totalTasksCompleted', totalTasksCompleted);
    localStorage.setItem('totalTasksCreated', totalTasksCreated);
    localStorage.setItem('productivityStreak', productivityStreak);
    localStorage.setItem('lastProductiveDay', lastProductiveDay);
}

function loadFromLocalStorage() {
    const savedTasks = localStorage.getItem('tasks');
    const savedCompletedTasks = localStorage.getItem('completedTasks');
    const savedTotalCompleted = localStorage.getItem('totalTasksCompleted');
    const savedTotalCreated = localStorage.getItem('totalTasksCreated');
    const savedStreak = localStorage.getItem('productivityStreak');
    const savedLastProductiveDay = localStorage.getItem('lastProductiveDay');

    if (savedTasks) tasks = JSON.parse(savedTasks);
    if (savedCompletedTasks) completedTasks = JSON.parse(savedCompletedTasks);
    if (savedTotalCompleted) totalTasksCompleted = parseInt(savedTotalCompleted);
    if (savedTotalCreated) totalTasksCreated = parseInt(savedTotalCreated);
    if (savedStreak) productivityStreak = parseInt(savedStreak);
    if (savedLastProductiveDay) lastProductiveDay = savedLastProductiveDay;
}

document.addEventListener('DOMContentLoaded', function() {
    loadChatHistory();
    
    const sendButton = document.getElementById('sendButton');
    sendButton.addEventListener('click', handleSendMessage);

    const userInput = document.getElementById('userInput');
    userInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSendMessage();
        }
    });

    const clearChatButton = document.getElementById('clearChatButton');
    clearChatButton.addEventListener('click', clearChat);

    const saveChatButton = document.getElementById('saveChatButton');
    saveChatButton.addEventListener('click', saveChatHistory);
});

// For testing purposes
//localStorage.setItem('token', 'fake-token-for-testing');

// Initialize the app
document.addEventListener('DOMContentLoaded', initializeApp);

// Add this new function to handle the Today button click
function goToToday() {
    currentDate = new Date();
    renderCalendar();
}

function updateProgressTracking() {
    // Update task completion rate
    const completionRate = totalTasksCreated > 0 
        ? ((totalTasksCompleted / totalTasksCreated) * 100).toFixed(1) 
        : 0;
    
    const taskCompletionRateElement = document.getElementById('taskCompletionRate');
    if (taskCompletionRateElement) {
        taskCompletionRateElement.textContent = `Task Completion Rate: ${completionRate}%`;
    }

    // Update total study time
    const hours = Math.floor(totalStudyTime / 3600);
    const minutes = Math.floor((totalStudyTime % 3600) / 60);
    
    const totalStudyTimeElement = document.getElementById('totalStudyTime');
    if (totalStudyTimeElement) {
        totalStudyTimeElement.textContent = `Total Study Time: ${hours}h ${minutes}m`;
    }

    // Update productivity streak
    const productivityStreakElement = document.getElementById('productivityStreak');
    if (productivityStreakElement) {
        productivityStreakElement.textContent = `Current Streak: ${productivityStreak} days`;
    }

    // Update charts
    updateCharts();
}

function updateCharts() {
    // Task Completion Chart
    if (charts.taskCompletion) {
        charts.taskCompletion.destroy();
    }
    const taskCtx = document.getElementById('taskCompletionChart').getContext('2d');
    charts.taskCompletion = new Chart(taskCtx, {
        type: 'doughnut',
        data: {
            labels: ['Completed', 'Pending'],
            datasets: [{
                data: [totalTasksCompleted, totalTasksCreated - totalTasksCompleted],
                backgroundColor: ['#03dac6', '#6200ee']
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false
        }
    });

    // Study Time Chart
    if (charts.studyTime) {
        charts.studyTime.destroy();
    }
    const studyCtx = document.getElementById('studyTimeChart').getContext('2d');
    const studyData = studySessionsHistory.slice(-7).map(session => ({
        date: new Date(session.date).toLocaleDateString(),
        duration: session.duration / 60 // Convert to minutes
    }));

    charts.studyTime = new Chart(studyCtx, {
        type: 'bar',
        data: {
            labels: studyData.map(d => d.date),
            datasets: [{
                label: 'Study Time (minutes)',
                data: studyData.map(d => d.duration),
                backgroundColor: '#03dac6'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    // Subject Performance Chart
    if (charts.subjectPerformance) {
        charts.subjectPerformance.destroy();
    }
    const subjectCtx = document.getElementById('subjectPerformanceChart').getContext('2d');
    const subjectData = {};
    
    // Aggregate completed tasks by subject
    completedTasks.forEach(task => {
        if (!subjectData[task.subject]) {
            subjectData[task.subject] = 0;
        }
        subjectData[task.subject]++;
    });

    charts.subjectPerformance = new Chart(subjectCtx, {
        type: 'pie',
        data: {
            labels: Object.keys(subjectData),
            datasets: [{
                data: Object.values(subjectData),
                backgroundColor: [
                    '#03dac6',
                    '#6200ee',
                    '#ff4081',
                    '#ffab00',
                    '#00e676'
                ]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false
        }
    });
}

// Add these functions to track task statistics
function updateTaskStatistics(isNewTask = false, isCompleted = false) {
    if (isNewTask) {
        totalTasksCreated++;
    }
    if (isCompleted) {
        totalTasksCompleted++;
        
        // Update productivity streak
        const today = new Date().toDateString();
        if (lastProductiveDay !== today) {
            productivityStreak++;
            lastProductiveDay = today;
        }
    }
    saveToLocalStorage();
}

// Update the addTask function
function addTask(taskData) {
    tasks.push(taskData);
    updateTaskStatistics(true); // New task created
    saveToLocalStorage();
    renderCalendar();
    showNotification('Task added successfully');
    closeModal('addTaskModal');
}

// Update the completeTask function
function completeTask(taskId) {
    const taskIndex = tasks.findIndex(task => task.id === taskId);
    if (taskIndex !== -1) {
        const completedTask = tasks[taskIndex];
        completedTasks.push(completedTask);
        tasks.splice(taskIndex, 1);
        
        // Update task statistics
        totalTasksCompleted++;
        
        // Update productivity streak
        const today = new Date().toDateString();
        if (lastProductiveDay !== today) {
            productivityStreak++;
            lastProductiveDay = today;
        }
        
        saveToLocalStorage();
        renderCalendar();
        updateProgressTracking();
        showNotification('Task completed successfully!');
    }
}

// Update study session tracking
function updateStudyStatistics(duration) {
    totalStudyTime += duration;
    const sessionData = {
        date: new Date().toISOString(),
        duration: duration
    };
    studySessionsHistory.push(sessionData);
    saveToLocalStorage();
}

// Update modal functions
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'block';
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'none';
        // Reset form if it exists
        const form = modal.querySelector('form');
        if (form) {
            form.reset();
        }
    }
}

// Add event listeners for modal close buttons
document.addEventListener('DOMContentLoaded', function() {
    // ... existing DOMContentLoaded code ...

    // Close modal when clicking outside
    window.addEventListener('click', (event) => {
        if (event.target.classList.contains('modal')) {
            closeModal(event.target.id);
        }
    });

    // Close modal when clicking cancel button
    const cancelButtons = document.querySelectorAll('.modal-buttons button:last-child');
    cancelButtons.forEach(button => {
        button.addEventListener('click', () => {
            const modal = button.closest('.modal');
            if (modal) {
                closeModal(modal.id);
            }
        });
    });
});

function clearProgressHistory() {
    // Reset all tracking variables
    totalTasksCompleted = 0;
    totalTasksCreated = 0;
    totalStudyTime = 0;
    productivityStreak = 0;
    lastProductiveDay = null;
    studySessionsHistory = [];
    completedTasks = [];
    
    // Save the cleared state
    saveToLocalStorage();
    
    // Update the display
    updateProgressTracking();
    showNotification('Progress history cleared successfully');
}

// Update the task rendering function
function renderTask(task) {
    return `
        <div class="task ${task.completed ? 'completed' : ''}" data-id="${task.id}">
            <div class="task-content">
                <h4>${task.name}</h4>
                <p>Time: ${task.time}</p>
                <p>Priority: ${task.priority}</p>
                <p>Subject: ${task.subject}</p>
                ${task.notes ? `<p>Notes: ${task.notes}</p>` : ''}
            </div>
            <div class="task-actions">
                <input type="checkbox" class="task-checkbox" 
                    ${task.completed ? 'checked' : ''} 
                    onclick="toggleTaskCompletion('${task.id}')">
                <button class="edit-button" onclick="editTask('${task.id}')">Edit</button>
            </div>
        </div>
    `;
}

// Update the task completion toggle function
function toggleTaskCompletion(taskId) {
    const taskIndex = tasks.findIndex(task => task.id === taskId);
    if (taskIndex !== -1) {
        const task = tasks[taskIndex];
        task.completed = !task.completed;
        
        if (task.completed) {
            completedTasks.push({...task});
            tasks.splice(taskIndex, 1);
            totalTasksCompleted++;
            
            // Update productivity streak
            const today = new Date().toDateString();
            if (lastProductiveDay !== today) {
                productivityStreak++;
                lastProductiveDay = today;
            }
        }
        
        saveToLocalStorage();
        renderSchedule();
        renderCalendar();
        updateProgressTracking();
        showNotification(task.completed ? 'Task completed!' : 'Task uncompleted');
    }
}


// Add CSS for task actions
const styleSheet = document.createElement('style');
styleSheet.textContent = `
    .task-actions {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        margin-top: 1rem;
    }

    .task-checkbox {
        width: 20px;
        height: 20px;
        cursor: pointer;
    }

    .task-actions button {
        padding: 0.5rem 1rem;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        transition: background-color 0.3s, transform 0.2s;
    }

    .task-actions .edit-button {
        background-color: var(--primary-color);
        color: var(--on-surface-color);
    }

    .task-actions .delete-button {
        background-color: var(--error-color);
        color: var(--on-surface-color);
    }

    .task-actions button:hover {
        transform: translateY(-2px);
    }
`;
document.head.appendChild(styleSheet);

// Function to save chat history as a text file
function saveChatHistoryAsFile() {
    const chatHistoryText = chatHistory.map(msg => `${msg.sender}: ${msg.message}`).join('\n');
    const blob = new Blob([chatHistoryText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = 'chat_history.txt'; // Name of the file
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}
// Bind the save button to the save function
document.getElementById('saveChatButton').addEventListener('click', saveChatHistoryAsFile);
function cleanup() {
    // Remove event listeners
    document.removeEventListener('click', handleClick);
    clearInterval(timerInterval);
}
